<?php
$database = 'dcu';
$host = 'localhost';
$user = 'root';
$pass = '';
$conn= mysqli_connect($host, $user, $pass, $database);

	