<?php
include "inc/header.php"
?>


<div class="container">
<div class="content">
    <h1>Welcome to the Admin Dashboard</h1>
    <p>This is a sample content area. You can add your dashboard content here.</p>
    <a href="users.php" class="btn btn-primary"> VIEW ALL USERS  </a>
    <a href="transactions.php" class="btn btn-success"> VIEW ALL TRANSACTION  </a>
</div>
</div>


<?php
include "inc/footer.php";
?>